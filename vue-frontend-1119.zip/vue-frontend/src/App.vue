<template>
  <div id="app" class="app-header"> <!-- 为整个顶部分配一个类 -->
    <div class="user-status">
      <span v-if="!isLoggedIn">未登录</span>
      <span v-else>欢迎, {{ currentUser }}</span>
    </div>
    <h1>商品比价网站</h1>
    <nav>
      <router-link to="/">Home</router-link> |
      <router-link to="/mainpage">Main</router-link> |
      <router-link to="/starpage">Star</router-link>
    </nav>
    <!-- 这里是页面内容切换的地方 -->
    <router-view v-model:favorites="favorites" @login-success="handleLogin"></router-view>
  </div>
</template>

<script>
export default {
  name: 'App',
  data() {
    return {
      favorites: [], // 全局定义的收藏夹数组
      isLoggedIn: false, // 登录状态
      currentUser: '' // 当前用户名
    };
  },
  methods: {
    handleLogin(username) {
      this.isLoggedIn = true;
      this.currentUser = username;
    }
  }
};
</script>

<style scoped>
/* 为整个 header 区域设置渐变背景 */
.app-header {
  background: linear-gradient(to right, #ff7e5f, #feb47b); /* 渐变背景 */
  padding: 20px; /* 给整体增加一些内边距，保持内容的间距 */
  position: relative;
}

h1 {
  margin: 0; /* 去掉默认的 h1 上下边距 */
  color: white; /* 使标题文字与背景对比明显 */
}

nav {
  margin-top: 10px;
  display: flex;
  justify-content: flex-end;
}

nav a {
  margin: 0 10px;
  text-decoration: none;
  color: white; /* 使导航按钮颜色与背景对比明显 */
}

.user-status {
  position: absolute;
  top: 8px;
  right: 20px;
  color: white;
  font-size: 14px;
}
</style>
