import { createRouter, createWebHistory } from "vue-router";

import AboutPage from "@/components/AboutPage.vue";
import HomePage from "@/components/HomePage.vue";
import MainPage from "@/components/MainPage.vue";
import StarPage from "@/components/StarPage.vue";

const routes = [
  {
    path: '/',
    component: HomePage,  // 当访问 "/" 路径时，加载 Home 组件
  },
  {
    path: '/register',
    component: AboutPage, // 当访问 "/about" 路径时，加载 About 组件
  },
  {
    path: '/mainpage',
    component: MainPage, // 当访问 "/main" 路径时，加载 Main 组件
  },
  {
    path: '/starpage',
    component: StarPage, // 当访问 "/star" 路径时，加载 Star 组件
  },
];

const router = createRouter({
  history: createWebHistory(),
  routes,  // 配置路由
});

export default router;
