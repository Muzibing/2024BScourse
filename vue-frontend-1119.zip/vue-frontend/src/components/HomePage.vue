<template>
  <div class="login-container">
    <div class="login-box">
      <h1>登录</h1>
      <form @submit.prevent="login">
        <div class="input-group">
          <label for="username">用户名</label>
          <input type="text" v-model="username" id="username" required placeholder="请输入用户名">
        </div>
        <div class="input-group">
          <label for="password">密码</label>
          <input type="password" v-model="password" id="password" required placeholder="请输入密码">
        </div>
        <button type="submit" class="login-button">登录</button>
        <p v-if="errorMessage" class="error-message">{{ errorMessage }}</p>
      </form>
      <div v-if="loginSuccess" class="success-message">
        <p>登录成功，欢迎 {{ username }}！</p>
        <button @click="navigateToMainPage" class="mainpage-button">前往主页面</button>
      </div>
      <p class="register-link" v-if="!loginSuccess">没有账号？<router-link to="/register">点击这里注册</router-link></p>
    </div>
  </div>
</template>

<script>
export default {
  name: "HomePage",
  data() {
    return {
      username: '',
      password: '',
      errorMessage: '',
      loginSuccess: false // 登录状态
    };
  },
  methods: {
    async login() {
      try {
        const response = await fetch('http://127.0.0.1:8001/login', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            username: this.username,
            password: this.password,
          }),
        });

        if (response.ok) {
          // 登录成功，显示成功消息
          this.loginSuccess = true;
          this.errorMessage = '';
          // 触发父组件事件并传递用户名
          this.$emit('login-success', this.username);
        } else {
          this.errorMessage = '用户名或密码不正确';
        }
      } catch (error) {
        console.log("登录失败");
        this.errorMessage = '登录时发生错误，请稍后再试。';
      }
    },
    navigateToMainPage() {
      this.$router.push('/mainpage');
    }
  },
};
</script>

<style scoped>
/* 样式布局让页面居中 */
.login-container {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background-color: #f5f5f5;
}

.login-box {
  background-color: white;
  padding: 40px;
  border-radius: 10px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  width: 300px;
  text-align: center;
}

h1 {
  margin-bottom: 20px;
  font-size: 24px;
  color: #333;
}

.input-group {
  margin-bottom: 15px;
  text-align: left;
}

.input-group label {
  display: block;
  margin-bottom: 5px;
  font-size: 14px;
  color: #666;
}

.input-group input {
  width: 100%;
  padding: 10px;
  font-size: 14px;
  border: 1px solid #ccc;
  border-radius: 5px;
  box-sizing: border-box;
}

.input-group input:focus {
  border-color: #007BFF;
  outline: none;
}

.login-button {
  width: 100%;
  padding: 10px;
  background-color: #007BFF;
  color: white;
  font-size: 16px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

.login-button:hover {
  background-color: #0056b3;
}

.error-message {
  color: red;
  margin-top: 10px;
}

.success-message {
  color: green;
  margin-top: 20px;
}

.mainpage-button {
  margin-top: 10px;
  padding: 8px 16px;
  background-color: #28a745;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

.mainpage-button:hover {
  background-color: #218838;
}

.register-link {
  margin-top: 20px;
  font-size: 14px;
}

.register-link a {
  color: #007BFF;
  text-decoration: none;
}

.register-link a:hover {
  text-decoration: underline;
}
</style>
