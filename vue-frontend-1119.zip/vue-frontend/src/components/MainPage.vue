<template>
  <div class="search-container">
    <div class="search-bar">
      <input type="text" v-model="productName" placeholder="请输入商品名称">
      <input type="number" v-model="minPrice" placeholder="最低价">
      <span> - </span>
      <input type="number" v-model="maxPrice" placeholder="最高价">
      <label><input type="checkbox" v-model="platforms.taobao"> 淘宝</label>
      <label><input type="checkbox" v-model="platforms.jd"> 京东</label>
      <label><input type="checkbox" v-model="platforms.suning"> 苏宁</label>
      <button @click="searchProducts" class="search-button">搜索</button>
      <!-- 按价格排序/恢复推荐排序按钮 -->
      <button @click="toggleSort" class="sort-button">
        {{ isSortedByPrice ? "按默认推荐排序" : "按价格从低到高排序" }}
      </button>
    </div>

    <div class="search-results">
      <div v-for="(result, index) in searchResults" :key="index" class="result-item">
        <img :src="result.image" alt="商品图片" class="product-image">
        <div class="product-info">
          <p class="product-name">{{ result.name }}</p>
          <p class="product-price">¥{{ result.price }}</p>
          <p class="product-from">{{ mappedFrom(result.from) }}</p>
        </div>
        <button @click="toggleFavorite(result)" class="favorite-button">
          <span v-if="isFavorited(result)">★</span>
          <span v-else>☆</span>
        </button>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "MainPage",
  props: {
    favorites: {
      type: Array,
      required: true
    }
  },
  data() {
    return {
      productName: '',
      minPrice: null,
      maxPrice: null,
      platforms: {
        taobao: false,
        jd: false,
        suning: false
      },
      searchResults: [],
      originalResults: [], // 用于保存默认推荐排序的商品列表
      isSortedByPrice: false // 标识当前是否按价格排序
    };
  },
  methods: {
    async searchProducts() {
      try {
        const response = await fetch(`http://127.0.0.1:8001/api/search?query=${this.productName}`, {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
          }
        });

        // 检查 API 返回的数据格式
        const data = await response.json();

        // 确保 data 是数组
        if (Array.isArray(data)) {
          this.searchResults = data;
          this.originalResults = [...data]; // 保存原始顺序的商品列表
        } else {
          console.error('API 返回的数据格式不正确，期望数组，实际得到:', data);
          this.searchResults = []; // 发生错误时清空搜索结果
          this.originalResults = [];
        }

        // 筛选商品来源
        let results = this.searchResults.length > 0 ? this.searchResults : [];
        let allowedSources = [];
        if (this.platforms.taobao && this.platforms.jd) {
          allowedSources = ['UlandTaoBao', 'JingDong'];
        } else if (this.platforms.jd) {
          allowedSources = ['JingDong'];
        } else if (this.platforms.taobao) {
          allowedSources = ['UlandTaoBao'];
        }

        results = results.filter(item => allowedSources.includes(item.from));

        // 根据价格范围筛选
        if (this.minPrice !== null) {
          results = results.filter(item => item.price >= this.minPrice);
        }
        if (this.maxPrice !== null) {
          results = results.filter(item => item.price <= this.maxPrice);
        }

        // 更新搜索结果
        this.searchResults = results;
        this.originalResults = [...results];
      } catch (error) {
        console.error('搜索过程中发生错误:', error);
      }
    },
    // 映射来源字段为中文名称
    mappedFrom(from) {
      const mapping = {
        'JingDong': '来源：京东',
        'UlandTaoBao': '来源：淘宝'
      };
      return mapping[from] || from;
    },
    // 切换排序方式
    toggleSort() {
      if (this.isSortedByPrice) {
        // 恢复为默认推荐排序
        this.searchResults = [...this.originalResults];
      } else {
        // 按价格从低到高排序
        this.searchResults = [...this.searchResults].sort((a, b) => a.price - b.price);
      }
      this.isSortedByPrice = !this.isSortedByPrice;
    },
    async toggleFavorite(product) {
      try {
        // 判断当前商品是否已被收藏
        const isFavorited = this.isFavorited(product);
        if (isFavorited) {
          // 取消收藏：删除数据库中的记录
          await this.removeFavorite(product);
        } else {
          // 收藏商品：添加到数据库
          await this.addFavorite(product);
        }
      } catch (error) {
        console.error('操作收藏时发生错误:', error);
      }
    },
    isFavorited(product) {
      return this.favorites.some(item => item.name === product.name);
    },
    // 添加收藏（向后端发送请求）
    async addFavorite(product) {
      try {
        const response = await fetch('http://127.0.0.1:8001/api/favorites', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            name: product.name,
            price: parseFloat(product.price),
            image: product.image,
            from_: product.from,
            link: product.link,
          }) // 传递商品信息
        });

        if (response.ok) {
          this.$emit('update:favorites', [...this.favorites, product]);
        } else {
          console.error('收藏商品时出错:', await response.text());
        }
      } catch (error) {
        console.error('添加收藏时发生错误:', error);
      }
    },
    // 取消收藏（向后端发送请求）
    async removeFavorite(product) {
      try {
        const response = await fetch('http://127.0.0.1:8001/api/favorites', {
          method: 'DELETE',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            name: product.name,
            price: parseFloat(product.price),
            image: product.image,
            from_: product.from,
            link: product.link,
          }) // 传递商品信息
        });

        if (response.ok) {
          this.$emit('update:favorites', this.favorites.filter(item => item.name !== product.name));
        } else {
          console.error('取消收藏时出错:', await response.text());
        }
      } catch (error) {
        console.error('删除收藏时发生错误:', error);
      }
    }
  }
};
</script>

<style scoped>
.search-container {
  padding: 20px;
  background-color: #f5f5f5;
}

.search-bar {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
  padding: 10px;
  background-color: #fff;
  border-radius: 5px;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
  margin-bottom: 20px;
}

input[type="text"], input[type="number"] {
  padding: 8px;
  font-size: 14px;
  border: 1px solid #ccc;
  border-radius: 5px;
  box-sizing: border-box;
}

input[type="number"] {
  width: 80px;
}

label {
  font-size: 14px;
}

.search-button, .sort-button {
  padding: 8px 16px;
  background-color: #007BFF;
  color: white;
  font-size: 14px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

.search-button:hover, .sort-button:hover {
  background-color: #0056b3;
}

.search-results {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  gap: 20px;
}

.result-item {
  width: 150px;
  text-align: center;
  background-color: #fff;
  padding: 10px;
  border-radius: 5px;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
  position: relative;
}

.product-image {
  width: 100px;
  height: 100px;
  object-fit: cover;
  border-radius: 5px;
}

.product-info {
  margin-top: 10px;
}

.product-name, .product-from {
  font-size: 14px;
  font-weight: bold;
  color: #333;
}

.product-price {
  font-size: 14px;
  color: #007BFF;
}

.favorite-button {
  position: absolute;
  bottom: 5px;
  right: 5px;
  background: none;
  border: none;
  cursor: pointer;
  font-size: 18px;
  color: #FFD700;
}

.favorite-button:hover {
  color: #FFA500;
}
</style>
