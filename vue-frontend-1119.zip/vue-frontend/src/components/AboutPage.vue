<template>
  <div class="form-container">
    <h1>注册</h1>
    <form @submit.prevent="register">
      <div class="input-group">
        <label for="username">用户名：</label>
        <input type="text" v-model="username" id="username" required>
      </div>
      <div class="input-group">
        <label for="email">电子邮件：</label>
        <input type="email" v-model="email" id="email" required>
      </div>
      <div class="input-group">
        <label for="password">密码：</label>
        <input type="password" v-model="password" id="password" required>
      </div>
      <div class="input-group">
        <label for="confirmPassword">确认密码：</label>
        <input type="password" v-model="confirmPassword" id="confirmPassword" required>
      </div>
      <div class="button-container">
        <button type="submit">注册</button>
      </div>
      <div v-if="errorMessage" class="error-message">{{ errorMessage }}</div>
      <div v-if="successMessage" class="success-message">{{ successMessage }}</div>
    </form>
    <p class="login-link">已有账户？ <router-link to="/">立即登录</router-link></p>
  </div>
</template>

<script>
export default {
  name: "AboutPage",
  data() {
    return {
      username: '',
      email: '',
      password: '',
      confirmPassword: '',
      errorMessage: '',
      successMessage: '',
    };
  },
  methods: {
    async register() {
      // 校验用户名和密码大于6字节
      if (this.username.length < 6){
        this.errorMessage = '用户名需要大于6个字符！';
        this.successMessage = '';
        return;
      }

      if (this.password.length < 6){
        this.errorMessage = '密码需要大于6个字符！';
        this.successMessage = '';
        return;
      }

      // 校验密码是否匹配
      if (this.password !== this.confirmPassword) {
        this.errorMessage = '两次输入的密码不一致！';
        this.successMessage = '';
        return;
      }

      try {
        const response = await fetch('http://127.0.0.1:8001/register', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            username: this.username,
            email: this.email,
            password: this.password,
          }),
        });

        const data = await response.json();

        if (response.ok) {
          this.successMessage = '注册成功！正在跳转到登录页面...';
          this.errorMessage = '';
          setTimeout(() => {
            this.$router.push('/');
          }, 2000);
        } else {
          this.errorMessage = data.message || '注册失败';
          this.successMessage = '';
        }
      } catch (error) {
        this.errorMessage = '注册时发生错误，请稍后再试。';
        this.successMessage = '';
      }
    },
  },
};
</script>

<style scoped>
.form-container {
  max-width: 350px;
  margin: 0 auto;
  padding: 30px;
  border: 1px solid #ddd;
  border-radius: 8px;
  box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.1);
  background-color: #fff;
}

h1 {
  text-align: center;
  margin-bottom: 20px;
  font-size: 24px;
  color: #333;
}

.input-group {
  margin-bottom: 15px;
}

.input-group label {
  display: block;
  margin-bottom: 5px;
  font-size: 14px;
  color: #555;
}

.input-group input {
  width: 100%;
  padding: 8px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  font-size: 14px;
}

.button-container {
  display: flex;
  justify-content: center;
  margin-top: 20px;
}

button {
  width: 100%;
  padding: 10px;
  background-color: #4CAF50;
  color: #fff;
  border: none;
  border-radius: 4px;
  font-size: 16px;
  cursor: pointer;
}

button:hover {
  background-color: #45a049;
}

.error-message {
  color: red;
  text-align: center;
  margin-top: 10px;
}

.success-message {
  color: green;
  text-align: center;
  margin-top: 10px;
}

.login-link {
  text-align: center;
  margin-top: 20px;
}

.login-link a {
  color: #007BFF;
  text-decoration: none;
}

.login-link a:hover {
  text-decoration: underline;
}
</style>
