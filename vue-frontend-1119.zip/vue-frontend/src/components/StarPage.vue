<template>
  <div class="favorites-container">
    <h2>收藏夹</h2>
    <div v-if="favorites.length === 0" class="no-favorites">暂无收藏的商品</div>
    <div v-else class="favorites-results">
      <div v-for="(item, index) in favorites" :key="index" class="favorite-item">
        <img :src="item.image" alt="商品图片" class="product-image">
        <div class="product-info">
          <p class="product-name">{{ item.name }}</p>
          <p class="product-price">¥{{ item.price }}</p>
          <!-- 收藏按钮 -->
          <button @click="removeFavorite(item)" class="favorite-button">移除收藏</button>
          <!-- 展示详细信息按钮 -->
          <button @click="showDetails(item)" class="details-button">展示详细信息</button>
        </div>
      </div>
    </div>

    <!-- 详细信息模态框 -->
    <div v-if="selectedProduct" class="details-modal">
      <div class="modal-content">
        <h3>商品详情</h3>
        <p><strong>名称：</strong>{{ selectedProduct.name }}</p>
        <p><strong>价格：</strong>¥{{ selectedProduct.price }}</p>
        <p><strong>多级品类：</strong>{{ selectedProduct.categories || '暂无信息' }}</p>
        <p><strong>规格：</strong>{{ selectedProduct.specs || '暂无信息' }}</p>
        <p><strong>条码：</strong>{{ selectedProduct.barcode || '暂无信息' }}</p>
        <h4>历史价格走势图</h4>
        <!-- 这里可以嵌入价格走势图组件或图表 -->
        <div class="chart-placeholder">价格走势图</div>
        <button @click="closeDetails" class="close-button">关闭</button>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "StarPage",
  props: {
    favorites: {
      type: Array,
      required: true,
    },
  },
  data() {
    return {
      selectedProduct: null, // 存储被选中的商品
    };
  },
  methods: {
    showDetails(product) {
      this.selectedProduct = product;
    },
    closeDetails() {
      this.selectedProduct = null;
    },
    async removeFavorite(product) {
      try {
        const response = await fetch("http://127.0.0.1:8001/api/favorites", {
          method: "DELETE",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            name: product.name,
            price: parseFloat(product.price),
            image: product.image,
            from_: product.from,
            link: product.link,
          }), // 传递商品信息
        });

        if (response.ok) {
          // 更新本地收藏夹列表
          this.$emit(
            "update:favorites",
            this.favorites.filter((item) => item.name !== product.name)
          );
        } else {
          console.error("取消收藏时出错:", await response.text());
        }
      } catch (error) {
        console.error("删除收藏时发生错误:", error);
      }
    },
  },
};
</script>

<style scoped>
.favorites-container {
  padding: 20px;
  background-color: #f5f5f5;
  border-radius: 5px;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}

h2 {
  text-align: center;
  margin-bottom: 20px;
}

.no-favorites {
  text-align: center;
  color: #888;
  font-size: 16px;
}

.favorites-results {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  gap: 20px;
}

.favorite-item {
  width: 150px;
  text-align: center;
  background-color: #fff;
  padding: 10px;
  border-radius: 5px;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}

.product-image {
  width: 100px;
  height: 100px;
  object-fit: cover;
  border-radius: 5px;
}

.product-info {
  margin-top: 10px;
}

.product-name {
  font-size: 14px;
  font-weight: bold;
  color: #333;
}

.product-price {
  font-size: 14px;
  color: #007BFF;
}

.favorite-button {
  margin-top: 5px;
  padding: 5px 10px;
  background-color: #dc3545;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

.favorite-button:hover {
  background-color: #c82333;
}

.details-button {
  margin-top: 10px;
  padding: 5px 10px;
  background-color: #28a745;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

.details-button:hover {
  background-color: #218838;
}

.details-modal {
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background-color: #fff;
  padding: 20px;
  border-radius: 10px;
  box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
  z-index: 1000;
}

.modal-content {
  text-align: left;
}

.chart-placeholder {
  height: 200px;
  background-color: #e9ecef;
  border-radius: 5px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: #6c757d;
}

.close-button {
  margin-top: 20px;
  padding: 5px 15px;
  background-color: #dc3545;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
}

.close-button:hover {
  background-color: #c82333;
}
</style>
